# JAV.my WebApp

Laman dewasa dengan subtitle Melayu dan langganan crypto. Dibina dengan Next.js