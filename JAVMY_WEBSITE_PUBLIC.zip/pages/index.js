export default function Home() {
  return (
    <main>
      <h1>Selamat Datang ke JAV.my</h1>
      <p>Laman dewasa dengan subtitle Bahasa Melayu.</p>
    </main>
  );
}
